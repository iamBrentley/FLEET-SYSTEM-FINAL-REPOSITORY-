﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class User
    {
        public static string LoggedUsersID;
        public static string LoggedUsersName;
        public static string LoggedUsersSurname;
        public static string LoggedUsersPosition;
    }
}
