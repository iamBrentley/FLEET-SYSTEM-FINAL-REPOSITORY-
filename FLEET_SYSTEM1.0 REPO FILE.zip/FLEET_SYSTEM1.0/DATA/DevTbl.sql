﻿CREATE TABLE [dbo].[DevlTbl]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Username] VARCHAR(50) NULL, 
    [Code] SMALLINT NULL
)
