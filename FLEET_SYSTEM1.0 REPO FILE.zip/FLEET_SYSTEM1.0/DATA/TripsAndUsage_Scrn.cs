﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLEET_SYSTEM1._0
{
    public partial class TripsAndUsage_Scrn : UserControl
    {
        public TripsAndUsage_Scrn()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnTrips_Daily_Click(object sender, EventArgs e)
        {

        }
    }
}
