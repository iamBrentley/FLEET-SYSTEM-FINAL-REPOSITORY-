﻿namespace FLEET_SYSTEM1._0
{
    partial class SignUpPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.label7 = new System.Windows.Forms.Label();
            this.rdbtnOfficeManager = new System.Windows.Forms.RadioButton();
            this.rdbtnVehicleInfoAdmin = new System.Windows.Forms.RadioButton();
            this.rdbtnTripManager = new System.Windows.Forms.RadioButton();
            this.rdbtnServiceManager = new System.Windows.Forms.RadioButton();
            this.rdbtnTimesheetManager = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.cmBoxSelectCompany = new System.Windows.Forms.ComboBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.cmbUserRole = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(129, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "First Name";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Location = new System.Drawing.Point(268, 268);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(76, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Sign Up";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtFirstName
            // 
            this.txtFirstName.BackColor = System.Drawing.SystemColors.Window;
            this.txtFirstName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFirstName.Location = new System.Drawing.Point(132, 126);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(160, 13);
            this.txtFirstName.TabIndex = 2;
            // 
            // txtLastName
            // 
            this.txtLastName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLastName.Location = new System.Drawing.Point(132, 187);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(160, 13);
            this.txtLastName.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(129, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Last Name";
            // 
            // txtPassword
            // 
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPassword.Location = new System.Drawing.Point(316, 187);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(160, 13);
            this.txtPassword.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(313, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Password";
            // 
            // txtUsername
            // 
            this.txtUsername.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUsername.Location = new System.Drawing.Point(316, 126);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(160, 13);
            this.txtUsername.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(313, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Username";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(363, 155);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(363, 97);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "*";
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(256, 325);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(100, 10);
            this.progressBar.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(9, 266);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Sign up as:";
            // 
            // rdbtnOfficeManager
            // 
            this.rdbtnOfficeManager.AutoSize = true;
            this.rdbtnOfficeManager.Location = new System.Drawing.Point(12, 282);
            this.rdbtnOfficeManager.Name = "rdbtnOfficeManager";
            this.rdbtnOfficeManager.Size = new System.Drawing.Size(98, 17);
            this.rdbtnOfficeManager.TabIndex = 14;
            this.rdbtnOfficeManager.TabStop = true;
            this.rdbtnOfficeManager.Text = "Office Manager";
            this.rdbtnOfficeManager.UseVisualStyleBackColor = true;
            // 
            // rdbtnVehicleInfoAdmin
            // 
            this.rdbtnVehicleInfoAdmin.AutoSize = true;
            this.rdbtnVehicleInfoAdmin.Location = new System.Drawing.Point(12, 306);
            this.rdbtnVehicleInfoAdmin.Name = "rdbtnVehicleInfoAdmin";
            this.rdbtnVehicleInfoAdmin.Size = new System.Drawing.Size(178, 17);
            this.rdbtnVehicleInfoAdmin.TabIndex = 15;
            this.rdbtnVehicleInfoAdmin.TabStop = true;
            this.rdbtnVehicleInfoAdmin.Text = "Vehicle Information Administrator";
            this.rdbtnVehicleInfoAdmin.UseVisualStyleBackColor = true;
            // 
            // rdbtnTripManager
            // 
            this.rdbtnTripManager.AutoSize = true;
            this.rdbtnTripManager.Location = new System.Drawing.Point(12, 329);
            this.rdbtnTripManager.Name = "rdbtnTripManager";
            this.rdbtnTripManager.Size = new System.Drawing.Size(88, 17);
            this.rdbtnTripManager.TabIndex = 16;
            this.rdbtnTripManager.TabStop = true;
            this.rdbtnTripManager.Text = "Trip Manager";
            this.rdbtnTripManager.UseVisualStyleBackColor = true;
            // 
            // rdbtnServiceManager
            // 
            this.rdbtnServiceManager.AutoSize = true;
            this.rdbtnServiceManager.Location = new System.Drawing.Point(12, 352);
            this.rdbtnServiceManager.Name = "rdbtnServiceManager";
            this.rdbtnServiceManager.Size = new System.Drawing.Size(106, 17);
            this.rdbtnServiceManager.TabIndex = 17;
            this.rdbtnServiceManager.TabStop = true;
            this.rdbtnServiceManager.Text = "Service Manager";
            this.rdbtnServiceManager.UseVisualStyleBackColor = true;
            // 
            // rdbtnTimesheetManager
            // 
            this.rdbtnTimesheetManager.AutoSize = true;
            this.rdbtnTimesheetManager.Location = new System.Drawing.Point(12, 375);
            this.rdbtnTimesheetManager.Name = "rdbtnTimesheetManager";
            this.rdbtnTimesheetManager.Size = new System.Drawing.Size(119, 17);
            this.rdbtnTimesheetManager.TabIndex = 18;
            this.rdbtnTimesheetManager.TabStop = true;
            this.rdbtnTimesheetManager.Text = "Timesheet Manager";
            this.rdbtnTimesheetManager.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(12, 44);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 16);
            this.label8.TabIndex = 19;
            this.label8.Text = "Select Company:";
            // 
            // cmBoxSelectCompany
            // 
            this.cmBoxSelectCompany.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmBoxSelectCompany.FormattingEnabled = true;
            this.cmBoxSelectCompany.Items.AddRange(new object[] {
            "",
            "Cargo Fleet"});
            this.cmBoxSelectCompany.Location = new System.Drawing.Point(158, 43);
            this.cmBoxSelectCompany.Name = "cmBoxSelectCompany";
            this.cmBoxSelectCompany.Size = new System.Drawing.Size(155, 21);
            this.cmBoxSelectCompany.TabIndex = 20;
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.SystemColors.Control;
            this.btnLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.btnLogin.Location = new System.Drawing.Point(268, 372);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(76, 23);
            this.btnLogin.TabIndex = 21;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(243, 356);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(127, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "Already have an account:";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Control;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button2.Location = new System.Drawing.Point(489, 299);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(41, 36);
            this.button2.TabIndex = 23;
            this.button2.Text = "clip";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // cmbUserRole
            // 
            this.cmbUserRole.FormattingEnabled = true;
            this.cmbUserRole.Items.AddRange(new object[] {
            "Office Manager",
            "Vehicle Information Administrator",
            "Trip Manager",
            "Service Manager",
            "Timesheet Manager"});
            this.cmbUserRole.Location = new System.Drawing.Point(215, 228);
            this.cmbUserRole.Name = "cmbUserRole";
            this.cmbUserRole.Size = new System.Drawing.Size(179, 21);
            this.cmbUserRole.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(275, 212);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "Sign up as:";
            // 
            // SignUpPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(596, 407);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cmbUserRole);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.cmBoxSelectCompany);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.rdbtnTimesheetManager);
            this.Controls.Add(this.rdbtnServiceManager);
            this.Controls.Add(this.rdbtnTripManager);
            this.Controls.Add(this.rdbtnVehicleInfoAdmin);
            this.Controls.Add(this.rdbtnOfficeManager);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "SignUpPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sign Up";
            this.Load += new System.EventHandler(this.SignUpPage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton rdbtnOfficeManager;
        private System.Windows.Forms.RadioButton rdbtnVehicleInfoAdmin;
        private System.Windows.Forms.RadioButton rdbtnTripManager;
        private System.Windows.Forms.RadioButton rdbtnServiceManager;
        private System.Windows.Forms.RadioButton rdbtnTimesheetManager;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmBoxSelectCompany;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cmbUserRole;
        private System.Windows.Forms.Label label10;
    }
}